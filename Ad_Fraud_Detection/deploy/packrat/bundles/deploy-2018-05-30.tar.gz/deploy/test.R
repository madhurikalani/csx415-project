library(packrat)
setwd("~/Madhuri stuff/Data_Science_Intro_R/Ad_Fraud_Detection/")
packrat::init()
packrat::set_opts(local.repos="~/Madhuri stuff/Data_Science_Intro_R/Ad_Fraud_Detection/pkgs")